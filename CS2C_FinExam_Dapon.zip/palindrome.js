// Prompt the user to enter the first WORD
let yword1 = prompt("Enter the first word:").toUpperCase(); // Added parentheses to call the function
// Prompt the user to enter the 2nd WORD
let yword2 = prompt("Enter the second word:").toUpperCase(); // Added parentheses to call the function

// Log the original string 1
console.log("String1:", yword1);
// Log the original string 2
console.log("String2:", yword2);

// Reverse the string (word1)
const revrsed1 = yword1.split('').reverse().join('');
// Reverse the string (word2)
const revrsed2 = yword2.split('').reverse().join('');

// Log the reversed string of word1
console.log("RevString1:", revrsed1);
// Log the reversed string of word2
console.log("RevString2:", revrsed2);

// Check if word1 is a palindrome
let wPal1 = yword1 === revrsed1;
// Check if word2 is a palindrome
let wPal2 = yword2 === revrsed2;

// Log the truth value of word1
console.log(yword1, "is equivalent to", revrsed1, "?", wPal1);
// Log the truth value of word2
