
//Prompt to ask the user to input numbers separated by commas
let numbers = prompt("Enter numbers:");
// Convert inout to an array of numbers
const numArray = numbers.split(',').map(Number); 
// Prompt to ask the user to input names separated by commas
let names = prompt("Enter names:");
// Convert input to an array of names
const namArray = names.split(',').map(name => name.trim()); 

// Merge both arrays into a single array
let mergArray = numArray.concat(namArray);
console.log("Merged:", mergArray);

// Sort the numbers numerically in reverse
let sortNumbers = numArray.sort((a, b) => b - a);
console.log("RevNumbers:", sortNumbers);
// Sort the names alphabetically
let sortNames = namArray.sort();
console.log("AlphaNames:", sortNames);