//Create an empty array to hold up to 5 grocery items
let groceryStack = [];

// Function to check if the stack is empty and return the top item
function peek() {
    if (groceryStack.length === 0) {
        console.log("The stack is empty.");
        return null; // Return null if the stack is empty
    } else {
        console.log("Top item:", groceryStack[groceryStack.length - 1]);
        return groceryStack[groceryStack.length - 1]; // Return the top item
    }
}

// Function to push an item onto the stack
function push(item) {
    groceryStack.push(item); //Add the item to the end of the array
    console.log("Pushed:", item);
    peek(); //Check the top item after pushing
    printStack(); //Print the current stack
}

//Function to pop an item from the stack
function pop() {
    if (peek() !== null) { //check if the stack is not empty
        const removedItem = groceryStack.pop(); //Remove the last item
        console.log("Popped: ", removedItem);
        peek(); //Check the top item after popping
        printStack(); //Print the current stack
    }
}

//Function to print the current state of the stack
function printStack() {
    console.log("Current Stack:", groceryStack.join(", "));
}

//Prompt the user to enter five grocery items
for (let i = 0; i < 5; i++) {
    const item = prompt("Enter grocery item", (i + 1),":");
    push(item); //Push each item onto the stack
}
//Example of popping an item from the stack
pop(); //Uncomment this line to test popping an item