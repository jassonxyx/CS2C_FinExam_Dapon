// Create an empty array to hold the numbers
let numbersArray = [];

// Function to prompt the user to enter numbers
function pplArray() {
    for (let i = 0; i < 10; i++) {
  //Convert input to a number and push to the array
        const number = prompt("Enter number", (i + 1), ":");
        numbersArray.push(Number(number));
    }
}

// Bubble Sort function
function bubbleSort(arr) {
    const n = arr.length;
    let swapped;

    // Outer loop for each pass
    do {
        swapped = false; // Reset swapped flag
        // Inner loop for comparing adjacent elements
        for (let i = 0; i < n - 1; i++) {
            if (arr[i] > arr[i + 1]) {
                // Swap if the current element is greater than the next
                [arr[i], arr[i + 1]] = [arr[i + 1], arr[i]];
                swapped = true; // Set swapped flag to true
            }
        }
    } while (swapped); // Repeat until no swaps are made

    return arr; // Return the sorted array
}

// Function to display the array
function displayArray(arr) {
    console.log("Sorted Array:", arr.join(", "));
}

// Populate the array with user input
pplArray();

// Sort the array using Bubble Sort
const sortedArray = bubbleSort(numbersArray);

// Display the sorted array
displayArray(sortedArray);