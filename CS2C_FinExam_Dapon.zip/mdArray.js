// Prompt the user to enter names separated by commas
let names = prompt("Enter names:");
// Convert input to an array of names
let namArray = names.split(',').map(name => name.trim());

// Prompt the user to enter ages separated by commas
let ages = prompt("Enter ages:");
// Convert input to an array of numbers
let ageArray = ages.split(',').map(Number);

// Restructure the arrays into a new multi-dimensional array
let resArray = namArray.map((name, index) => [name, ageArray[index]]);

// Log the restructured multi-dimensional array
console.log("Restructured:");
resArray.forEach(item => {
    console.log(item); // Logs each [name, age] pair
});